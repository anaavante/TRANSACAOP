module views.viva.views {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.net.http;
    requires okhttp3;
    requires org.json;
    requires java.sql;
    requires java.desktop;
    requires Bemathec;

    opens views.viva.views to javafx.fxml;
    exports views.viva.views;
}