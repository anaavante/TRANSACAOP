package views.viva.views;

import javafx.application.Application;

public class Laucher {
    public static void main(String[] args){
        Application.launch(App.class, args);
    }
}
