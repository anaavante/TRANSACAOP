package views.viva.views;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class historicoDepositosController {

    @FXML
    private AnchorPane anchorPanePrincipal;

    @FXML
    private Button btnRedirectNovaTransacao;

    @FXML
    private ImageView imgLogo;

    @FXML
    private Label lblCabecalho;

    @FXML
    private Pane paneCabecalho;

    @FXML
    private Pane panerincipal;

    @FXML
    private TableView<?> tblDados;

    @FXML
    private TableColumn<?, ?> tcl1;

    @FXML
    void btnRedirectNovaTransacaoClicked(MouseEvent event) throws IOException {
        App.setRoot("novaTransacao");
    }

}
