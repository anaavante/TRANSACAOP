package views.viva.views;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import javax.swing.*;
import java.io.IOException;

public class cadastroLojasController {

    @FXML
    private AnchorPane anchorPanePrincipal;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnRedirectCadEven;

    @FXML
    private Button btnRedirectLojasCad;

    @FXML
    private ImageView iconLogin;

    @FXML
    private ImageView iconNome;

    @FXML
    private ImageView iconSenha;

    @FXML
    private ImageView imgLogo;

    @FXML
    private ImageView imgUsuario;

    @FXML
    private Label lblLogin;

    @FXML
    private Label lblNome;

    @FXML
    private Label lblSenha;

    @FXML
    private Label lblTitulo;

    @FXML
    private Label lblUsuario;

    @FXML
    private Pane paneCabecalho;

    @FXML
    private Pane panePrincipal;

    @FXML
    private TextField txtLogin;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtSenha;

    @FXML
    void btnCadastrarClicked(MouseEvent event) {
        System.out.println("fsdsfdfds");
        metodosUteis metodosUteis = new metodosUteis();
        boolean verificador = metodosUteis.cadastrarUsuario(txtNome,txtSenha,txtLogin);
        System.out.println(verificador);
        if(verificador) {
            boolean verificador2 = metodosUteis.cadastrarLoja(txtNome,txtLogin);
            if(verificador2){
                JOptionPane.showMessageDialog(null, "Loja cadastrada");
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar loja");
        }
    }

    @FXML
    void btnRedirectCadEvenCliked(MouseEvent event) throws IOException {
        App.setRoot("cadastroEventos");
    }

    @FXML
    void btnRedirectLojasCadCliked(MouseEvent event) throws IOException {
        App.setRoot("lojasCadastradas");
    }

}
