package views.viva.views;

import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import org.json.JSONObject;

import javax.swing.*;
import java.sql.*;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class metodosUteis {

    private static final String bdURL = "jdbc:postgresql://pgsql.projetoscti.com.br/projetoscti24";
    private static final String bdUser = "projetoscti24";
    private static final String bdPassword = "eq23B159";
    private static Connection conn = null;

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(bdURL, bdUser, bdPassword);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return conn;
    }

    public String logar(TextField txtNome, TextField txtSenha) throws SQLException {
        String nome = txtNome.getText();
        String password = txtSenha.getText();

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        String adm = null;

        try {
            connection = getConnection();
            if (connection != null) {
                String sql = "SELECT u.login, u.senha " +
                        "FROM usuarios u " +
                        "INNER JOIN administradores a ON u.id_usuario = a.id_usuario " +
                        "WHERE a.cancelado_em IS NULL " +
                        "AND u.login = ? " +
                        "AND u.senha = ?";

                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, nome);
                preparedStatement.setString(2, password);

                resultSet = preparedStatement.executeQuery();

                String login = "";
                String senha = "";

                while (resultSet.next()) {
                    login = resultSet.getString("login");
                    senha = resultSet.getString("senha");
                }

                if (login.equals("adm1") && senha.equals("123")) {
                    adm = "cabello";
                } else if (login.equals("adm2") && senha.equals("123")) {
                    adm = "jovita";
                }
            }
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }

        return adm;
    }

    public boolean deposito(TextField txtCodigo, TextField txtValor, ChoiceBox txtTipo){
        String json = APICommunication.getBearerToken("adm1","123");
        String token = APICommunication.ConvertBearerToken(json);
        String body = "{\"codigo\": \"" + txtCodigo + "\", \"valor\": " + txtValor + ", \"tipo\": \"" + txtTipo + "\"}";
        String resultado = APICommunication.ReqPUT("http://localhost:3333/caixa/deposito",token,body);
        JSONObject jsonResponse = new JSONObject(resultado);
        return jsonResponse.getBoolean("sucesso");
    }

    public boolean cadastrarLoja(TextField txtNome, TextField txtLogin){
        String json = APICommunication.getBearerToken("adm1","123");
        String token = APICommunication.ConvertBearerToken(json);
        String body = "{\"login\": \""+txtLogin.getText()+"\", \"nome\": \""+txtNome.getText()+"\"}";
        String resultado = APICommunication.ReqPUT("http://localhost:3333/cadastro/vendedor",token,body);
        JSONObject jsonResponse = new JSONObject(resultado);
        return jsonResponse.getBoolean("sucesso");
    }

    public boolean cadastrarUsuario(TextField txtNome, TextField txtSenha, TextField txtLogin){
        String json = APICommunication.getBearerToken("adm1","123");
        String token = APICommunication.ConvertBearerToken(json);
        String body = "{\"nome\": \""+txtNome.getText()+"\", \"senha\": \""+txtSenha.getText()+"\", \"login\": \""+txtLogin.getText()+"\"}";
        String resultado = APICommunication.ReqPUT("http://localhost:3333/cadastro/usuario",token,body);
        JSONObject jsonResponse = new JSONObject(resultado);
            return jsonResponse.getBoolean("sucesso");
    }

    public List<vendedor> listaVendedores() throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<vendedor> vendedores = new ArrayList<vendedor>();

        try {
            connection = getConnection();

            String sql = "SELECT id_vendedor, loja, responsavel, ativo, ativado_em, criado_em, desativado_em FROM vendedores";

            if (connection != null) {
                preparedStatement = connection.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();

                 int idVendedor;
                 String loja;
                 long idUsuario;
                 long responsavel;
                 boolean ativo;
                 Timestamp ativadoEm;
                 Timestamp criadoEm;
                 Timestamp desativadoEm;

                while (resultSet.next()) {
                    idVendedor = resultSet.getInt("id_vendedor");
                    loja = resultSet.getString("loja");
                    responsavel = resultSet.getLong("responsavel");
                    ativo = resultSet.getBoolean("ativo");
                    ativadoEm = resultSet.getTimestamp("ativado_em");
                    criadoEm = resultSet.getTimestamp("criado_em");
                    desativadoEm = resultSet.getTimestamp("desativado_em");

                     vendedor vend = new vendedor(idVendedor,loja,responsavel,ativo,ativadoEm,criadoEm,desativadoEm);
                     vendedores.add(vend);
                }
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    return vendedores;
    }

    public void alterarAtivoVendedor(boolean ativo, int id_vendedor) throws SQLException {
        String json = APICommunication.getBearerToken("adm1","123");
        String token = APICommunication.ConvertBearerToken(json);
        String url = "http://localhost:3333/vendedor/alternarativo/"+id_vendedor;
        String body = "";
        String resultado = APICommunication.ReqPUT(url,token,body);
        JSONObject jsonResponse = new JSONObject(resultado);
        System.out.println(jsonResponse);
    }

    public List<eventos> listaEventos() throws SQLException {

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<eventos> eventos = new ArrayList<eventos>();

        try {
            connection = getConnection();

            String sql = "SELECT * FROM eventos";

            if (connection != null) {
                preparedStatement = connection.prepareStatement(sql);
                resultSet = preparedStatement.executeQuery();

                 int idEvento;
                 String nomeEvento;
                 long responsavel;
                 boolean ativo;
                 Timestamp horaInicio;
                 Timestamp horaFinal;
                 Timestamp finalizadoEm;
                 Timestamp desativadoEm;
                 Timestamp criadoEm;

                while (resultSet.next()) {
                    idEvento = resultSet.getInt("id_evento");
                    nomeEvento = resultSet.getString("nome_evento");
                    responsavel = resultSet.getLong("responsavel");
                    ativo = resultSet.getBoolean("ativo");
                    horaInicio = resultSet.getTimestamp("hora_inicio");
                    horaFinal = resultSet.getTimestamp("hora_final");
                    finalizadoEm = resultSet.getTimestamp("finalizado_em");
                    desativadoEm = resultSet.getTimestamp("desativado_em");
                    criadoEm = resultSet.getTimestamp("criado_em");

                    eventos even = new eventos(idEvento,nomeEvento,responsavel,ativo,horaInicio,horaFinal,finalizadoEm,desativadoEm,criadoEm);
                    eventos.add(even);
                }
            }
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
        finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
        return eventos;
    }

    public void alterarAtivoEventos(boolean ativo, int id_evento) throws SQLException {
        String json = APICommunication.getBearerToken("adm1","123");
        String token = APICommunication.ConvertBearerToken(json);
        String url = "http://localhost:3333/evento/alternarativo/"+id_evento;
        String body = "";
        String resultado = APICommunication.ReqPUT(url,token,body);
        JSONObject jsonResponse = new JSONObject(resultado);
        System.out.println(jsonResponse);
    }

}
