package views.viva.views;

import java.sql.Timestamp;
import java.time.ZonedDateTime;

    public class vendedor {
        private int idVendedor;
        private String loja;
        private long idUsuario;
        private long responsavel;
        private boolean ativo;
        private Timestamp ativadoEm;
        private Timestamp criadoEm;
        private Timestamp desativadoEm;

        public vendedor(int idVendedor, String loja, long idUsuario, long responsavel, boolean ativo, Timestamp ativadoEm, Timestamp criadoEm, Timestamp desativadoEm) {
            this.idVendedor = idVendedor;
            this.loja = loja;
            this.idUsuario = idUsuario;
            this.responsavel = responsavel;
            this.ativo = ativo;
            this.ativadoEm = ativadoEm;
            this.criadoEm = criadoEm;
            this.desativadoEm = desativadoEm;
        }
        public vendedor(int idVendedor ,String loja, long responsavel, boolean ativo, Timestamp ativadoEm, Timestamp criadoEm, Timestamp desativadoEm) {
            this.idVendedor = idVendedor;
            this.loja = loja;
            this.responsavel = responsavel;
            this.ativo = ativo;
            this.ativadoEm = ativadoEm;
            this.criadoEm = criadoEm;
            this.desativadoEm = desativadoEm;
        }

        public vendedor() {
            this.idVendedor = idVendedor;
            this.loja = loja;
            this.idUsuario = idUsuario;
            this.responsavel = responsavel;
            this.ativo = ativo;
            this.ativadoEm = ativadoEm;
            this.criadoEm = criadoEm;
            this.desativadoEm = desativadoEm;
        }



        // Getters and Setters
        public int getIdVendedor() {
            return idVendedor;
        }

        public void setIdVendedor(int idVendedor) {
            this.idVendedor = idVendedor;
        }

        public String getLoja() {
            return loja;
        }

        public void setLoja(String loja) {
            this.loja = loja;
        }

        public long getIdUsuario() {
            return idUsuario;
        }

        public void setIdUsuario(long idUsuario) {
            this.idUsuario = idUsuario;
        }

        public long getResponsavel() {
            return responsavel;
        }

        public void setResponsavel(long responsavel) {
            this.responsavel = responsavel;
        }

        public boolean isAtivo() {
            return ativo;
        }

        public void setAtivo(boolean ativo) {
            this.ativo = ativo;
        }

        public Timestamp getAtivadoEm() {
            return ativadoEm;
        }

        public void setAtivadoEm(Timestamp ativadoEm) {
            this.ativadoEm = ativadoEm;
        }

        public Timestamp getCriadoEm() {
            return criadoEm;
        }

        public void setCriadoEm(Timestamp criadoEm) {
            this.criadoEm = criadoEm;
        }

        public Timestamp getDesativadoEm() {
            return desativadoEm;
        }

        public void setDesativadoEm(Timestamp desativadoEm) {
            this.desativadoEm = desativadoEm;
        }
    }

