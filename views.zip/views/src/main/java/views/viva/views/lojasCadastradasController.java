package views.viva.views;

import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.ResourceBundle;

public class lojasCadastradasController implements Initializable {

    @FXML
    private AnchorPane anchorPanePrincipal;

    @FXML
    private Button btnAlterarAtivo;

    @FXML
    private Button btnRedirectCadLojas;

    @FXML
    private Button btnRedirectHistCancel;

    @FXML
    private TableColumn<vendedor, ZonedDateTime> columnAtivEm;

    @FXML
    private TableColumn<vendedor, Boolean> columnAtivo;

    @FXML
    private TableColumn<vendedor, ZonedDateTime> columnCriadEm;

    @FXML
    private TableColumn<vendedor, ZonedDateTime> columnDesaEm;

    @FXML
    private TableColumn<vendedor, String> columnNome;

    @FXML
    private TableColumn<vendedor, Long> columnResponsavel;

    @FXML
    private ImageView imgLogo;

    @FXML
    private Label lblCabecalho;

    @FXML
    private Pane paneCabecalho;

    @FXML
    private Pane panePrincipal;

    @FXML
    private TableView<vendedor> tblDados;

    private vendedor selecionado;


    @FXML
    void btnAlterarAtivoCliked(MouseEvent event) throws SQLException {
        if(selecionado != null){
            metodosUteis metodosUteis = new metodosUteis();
            metodosUteis.alterarAtivoVendedor(selecionado.isAtivo(), selecionado.getIdVendedor());
            tblDados.setItems(atualizaDados());
        }
    }

    @FXML
    void btnRedirectCadLojasCliked(MouseEvent event) throws IOException {
        App.setRoot("cadastroLojas");

    }

    @FXML
    void btnRedirectHistCancelCliked(MouseEvent event) throws IOException {
        App.setRoot("historicoCancelamento");

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            initTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        tblDados.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<vendedor>() {
            @Override
            public void changed(ObservableValue<? extends vendedor> observable, vendedor oldValue, vendedor newValue) {
                selecionado = (vendedor) newValue;
                System.out.println(selecionado);
            }
        });

    }

    public void initTable() throws SQLException {
        columnNome.setCellValueFactory(new PropertyValueFactory("loja"));
        columnResponsavel.setCellValueFactory(new PropertyValueFactory("responsavel"));
        columnAtivo.setCellValueFactory(new PropertyValueFactory("ativo"));
        columnAtivEm.setCellValueFactory(new PropertyValueFactory("ativadoEm"));
        columnCriadEm.setCellValueFactory(new PropertyValueFactory("criadoEm"));
        columnDesaEm.setCellValueFactory(new PropertyValueFactory("desativadoEm"));
        tblDados.setItems(atualizaDados());
    }

    public ObservableList<vendedor> atualizaDados() throws SQLException {
        metodosUteis metodosUteis = new metodosUteis();
        return FXCollections.observableArrayList(metodosUteis.listaVendedores());
    }

}



