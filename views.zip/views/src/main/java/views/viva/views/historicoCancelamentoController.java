package views.viva.views;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class historicoCancelamentoController {

    @FXML
    private Button btnRedirectEvenCad;

    @FXML
    private Button btnRedirectLojasCad;

    @FXML
    private ImageView imgLogo;

    @FXML
    private Label lblCabecalho;

    @FXML
    private TableView<?> tblDados;

    @FXML
    void btnRedirectEvenCadClicked(MouseEvent event) throws IOException {
        App.setRoot("eventosCadastrados");

    }

    @FXML
    void btnRedirectLojasCadClicked(MouseEvent event) throws IOException {
        App.setRoot("lojasCadastradas");

    }

}
