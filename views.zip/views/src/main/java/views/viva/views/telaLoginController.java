package views.viva.views;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.sql.SQLException;


public class telaLoginController {

    @FXML
    private Button btnEntrar;

    @FXML
    private ImageView imgLogo;

    @FXML
    private ImageView imgUsuario;

    @FXML
    private Label lblCabecalho;

    @FXML
    private Label lblNome;

    @FXML
    private Label lblSenha;

    @FXML
    private Label lblUsuario;

    @FXML
    private Pane paneCabecalho;

    @FXML
    private Pane panePrincipal;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtSenha;

    @FXML
    void btnEntrarClicked(MouseEvent event) throws SQLException, IOException {
        metodosUteis metodosUteis = new metodosUteis();
        String resultado = metodosUteis.logar(txtNome, txtSenha);
        if (resultado == "cabello") {
            App.setRoot("cadastroLojas");
        }
        if (resultado == "jovita") {
            App.setRoot("novaTransacao");
        } else {
            txtNome.setText("");
            txtSenha.setText("");
            txtNome.setPromptText("Nome incorreto");
            txtSenha.setPromptText("Senha incorreta");
            txtSenha.setStyle("-fx-prompt-text-fill: #ff5a5c;");
            txtNome.setStyle("-fx-prompt-text-fill: #ff5a5c;");

        }

    }

}
