package views.viva.views;

import java.sql.Timestamp;

public class eventos {
    private int idEvento;
    private long idInstituicao;
    private long responsavel;
    private boolean ativo;
    private String nomeEvento;
    private String abreviacaoEvento;
    private String descricaoEvento;
    private Timestamp horaInicio;
    private Timestamp horaFinal;
    private Timestamp finalizadoEm;
    private Timestamp desativadoEm;
    private Timestamp criadoEm;

    public eventos(int idEvento, long idInstituicao, long responsavel, boolean ativo, String nomeEvento, String abreviacaoEvento, String descricaoEvento, Timestamp horaInicio, Timestamp horaFinal, Timestamp finalizadoEm, Timestamp desativadoEm, Timestamp criadoEm) {
        this.idEvento = idEvento;
        this.idInstituicao = idInstituicao;
        this.responsavel = responsavel;
        this.ativo = ativo;
        this.nomeEvento = nomeEvento;
        this.abreviacaoEvento = abreviacaoEvento;
        this.descricaoEvento = descricaoEvento;
        this.horaInicio = horaInicio;
        this.horaFinal = horaFinal;
        this.finalizadoEm = finalizadoEm;
        this.desativadoEm = desativadoEm;
        this.criadoEm = criadoEm;
    }

    public eventos(int idEvento, String nomeEvento, long responsavel, boolean ativo, Timestamp horaInicio, Timestamp horaFinal, Timestamp finalizadoEm, Timestamp desativadoEm, Timestamp criadoEm) {
        this.idEvento = idEvento;
        this.nomeEvento = nomeEvento;
        this.responsavel = responsavel;
        this.ativo = ativo;
        this.horaInicio = horaInicio;
        this.horaFinal = horaFinal;
        this.finalizadoEm = finalizadoEm;
        this.desativadoEm = desativadoEm;
        this.criadoEm = criadoEm;
    }

    // Getters and Setters

    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public long getIdInstituicao() {
        return idInstituicao;
    }

    public void setIdInstituicao(long idInstituicao) {
        this.idInstituicao = idInstituicao;
    }

    public long getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(long responsavel) {
        this.responsavel = responsavel;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public String getNomeEvento() {
        return nomeEvento;
    }

    public void setNomeEvento(String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }

    public String getAbreviacaoEvento() {
        return abreviacaoEvento;
    }

    public void setAbreviacaoEvento(String abreviacaoEvento) {
        this.abreviacaoEvento = abreviacaoEvento;
    }

    public String getDescricaoEvento() {
        return descricaoEvento;
    }

    public void setDescricaoEvento(String descricaoEvento) {
        this.descricaoEvento = descricaoEvento;
    }

    public Timestamp getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Timestamp horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Timestamp getHoraFinal() {
        return horaFinal;
    }

    public void setHoraFinal(Timestamp horaFinal) {
        this.horaFinal = horaFinal;
    }

    public Timestamp getFinalizadoEm() {
        return finalizadoEm;
    }

    public void setFinalizadoEm(Timestamp finalizadoEm) {
        this.finalizadoEm = finalizadoEm;
    }

    public Timestamp getDesativadoEm() {
        return desativadoEm;
    }

    public void setDesativadoEm(Timestamp desativadoEm) {
        this.desativadoEm = desativadoEm;
    }

    public Timestamp getCriadoEm() {
        return criadoEm;
    }

    public void setCriadoEm(Timestamp criadoEm) {
        this.criadoEm = criadoEm;
    }

}
