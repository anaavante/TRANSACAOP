package views.viva.views;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class eventosCadastradosController implements Initializable {

    @FXML
    private AnchorPane anchorPanePrincipal;

    @FXML
    private Button btnAlterarAtivo;

    @FXML
    private Button btnRedirectCadEven;

    @FXML
    private Button btnRedirectHistCancel;

    @FXML
    private TableColumn<?, ?> columnAtivo;

    @FXML
    private TableColumn<?, ?> columnCriadoEm;

    @FXML
    private TableColumn<?, ?> columnDesativadoEm;

    @FXML
    private TableColumn<?, ?> columnFinalizadoEm;

    @FXML
    private TableColumn<?, ?> columnHrFim;

    @FXML
    private TableColumn<?, ?> columnHrInicio;

    @FXML
    private TableColumn<?, ?> columnNome;

    @FXML
    private TableColumn<?, ?> columnResp;


    @FXML
    private ImageView imgLogo;

    @FXML
    private Label lblCabecalho;

    @FXML
    private Pane paneCabecalho;

    @FXML
    private Pane panePrincipal;

    @FXML
    private TableView<eventos> tblDados;

    private eventos selecionado;

    @FXML
    void btnAlterarAtivoClicked(MouseEvent event) throws SQLException {
        if(selecionado != null){
            metodosUteis metodosUteis = new metodosUteis();
            metodosUteis.alterarAtivoEventos(selecionado.isAtivo(), selecionado.getIdEvento());
            tblDados.setItems(atualizaDados());
        }
    }

    @FXML
    void btnRedirectCadEvenClicked(MouseEvent event) throws IOException {
        App.setRoot("cadastroEventos");
    }

    @FXML
    void btnRedirectHistCancelClicked(MouseEvent event) throws IOException {
        App.setRoot("historicoCancelamento");
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            initTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        tblDados.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<eventos>() {
            @Override
            public void changed(ObservableValue<? extends eventos> observable, eventos oldValue, eventos newValue) {
                selecionado = (eventos) newValue;
                System.out.println(selecionado);
            }
        });

    }

    public void initTable() throws SQLException {
        columnAtivo.setCellValueFactory(new PropertyValueFactory("ativo"));
        columnCriadoEm.setCellValueFactory(new PropertyValueFactory("criadoEm"));
        columnNome.setCellValueFactory(new PropertyValueFactory("nomeEvento"));
        columnDesativadoEm.setCellValueFactory(new PropertyValueFactory("desativadoEm"));
        columnResp.setCellValueFactory(new PropertyValueFactory("responsavel"));
        columnFinalizadoEm.setCellValueFactory(new PropertyValueFactory("finalizadoEm"));
        columnHrFim.setCellValueFactory(new PropertyValueFactory("horaFinal"));
        columnHrInicio.setCellValueFactory(new PropertyValueFactory("horaInicio"));

        tblDados.setItems(atualizaDados());
    }

    public ObservableList<eventos> atualizaDados() throws SQLException {
        metodosUteis metodosUteis = new metodosUteis();
        return FXCollections.observableArrayList(metodosUteis.listaEventos());
    }

}
