package views.viva.views;

import java.io.IOException;
import java.sql.SQLException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

public class novaTransacaoController {

    @FXML
    private AnchorPane achorPanePrincipal;

    @FXML
    private Button btnEfetivar;

    @FXML
    private Button btnRedirectHistDepos;

    @FXML
    private Button btnRedirectHistExt;

    @FXML
    private ChoiceBox<?> chbTipo;

    @FXML
    private ImageView imgCodigo;

    @FXML
    private ImageView imgLogo;

    @FXML
    private ImageView imgTipo;

    @FXML
    private ImageView imgUsuario;

    @FXML
    private ImageView imgValor;

    @FXML
    private Label lblCabecalho;

    @FXML
    private Label lblCodigo;

    @FXML
    private Label lblTipo;

    @FXML
    private Label lblUsuario;

    @FXML
    private Label lblValor;

    @FXML
    private Pane panePrincipal;

    @FXML
    private TextField txtCodigo;

    @FXML
    private TextField txtValor;

    @FXML
    void btnEfetivarClicked(MouseEvent event) throws SQLException, IOException {
        metodosUteis metodosUteis = new metodosUteis();
        if(chbTipo=){

        }
        boolean resultado = metodosUteis.deposito(txtCodigo, txtValor, chbTipo);
        //if chb = dep ou ex
    }

    @FXML
    void btnRedirectHistDeposClicked(MouseEvent event) throws IOException {
        App.setRoot("historicoDepositos");

    }

    @FXML
    void btnRedirectHistExtClicked(MouseEvent event) throws IOException {
        App.setRoot("historicoDevolucoes");

    }

}
