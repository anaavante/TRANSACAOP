package views.viva.views;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import bemajava.*;

public class cadastroEventosController {

    @FXML
    private AnchorPane AnchorPanePrincipal;

    @FXML
    private Button btnCadastrar;

    @FXML
    private Button btnRedirectCadLojas;

    @FXML
    private Button btnRedirectEvenCad;

    @FXML
    private ComboBox<?> cmbLojas;

    @FXML
    private DatePicker dtpInicio;

    @FXML
    private DatePicker dtpTermino;

    @FXML
    private ImageView iconAbreviacao;

    @FXML
    private ImageView iconDescricao;

    @FXML
    private ImageView iconInicio;

    @FXML
    private ImageView iconLojas;

    @FXML
    private ImageView iconNome;

    @FXML
    private ImageView iconTermino;

    @FXML
    private ImageView imgUsuario;

    @FXML
    private Label lblAbreviacao;

    @FXML
    private Label lblDescricao;

    @FXML
    private Label lblInicio;

    @FXML
    private Label lblLojas;

    @FXML
    private Label lblNome;

    @FXML
    private Label lblTermino;

    @FXML
    private Label lblUsuario;

    @FXML
    private Pane panePrincipal;

    @FXML
    private Pane paneSecundario;

    @FXML
    private TextField txtAbreviacao;

    @FXML
    private TextField txtDescricao;

    @FXML
    private TextField txtNome;

    @FXML
    void btnCadastrarClicked(MouseEvent event) {
    }

    @FXML
    void btnRedirectCadLojasClicked(MouseEvent event) throws IOException {
        App.setRoot("cadastroLojas");
    }

    @FXML
    void btnRedirectEvenCadClicked(MouseEvent event) throws IOException {
        App.setRoot("eventosCadastrados");

    }

}
